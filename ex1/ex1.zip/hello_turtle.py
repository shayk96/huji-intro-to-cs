#################################################################
# FILE : hello_turtle.py
# WRITER : shay kvasha , shayk96 , 207902602
# EXERCISE : intro2cse ex1 2020
# DESCRIPTION: A simple program that draws 3 flowers
#################################################################
import turtle

def draw_petal():
    """
    This function draws the petal
    """
    turtle.forward(30)
    turtle.right(45)
    turtle.forward(30)
    turtle.right(135)
    turtle.forward(30)
    turtle.right(45)
    turtle.forward(30)
    turtle.right(135)


def draw_flower():
    """
    This function draws the flower
    """

    turtle.left(45)
    draw_petal()
    turtle.left(90)
    draw_petal()
    turtle.left(90)
    draw_petal()
    turtle.left(90)
    draw_petal()
    turtle.left(135)
    turtle.forward(150)


def draw_flower_and_advance():
    """
    This function draws the flower and moves to the start of the next one
    """
    draw_flower()
    turtle.right(90)
    turtle.up()
    turtle.forward(150)
    turtle.right(90)
    turtle.forward(150)
    turtle.left(90)
    turtle.down()


def draw_flower_bed():
    """
    This function draws the flower bed
    """
    turtle.up()
    turtle.forward(200)
    turtle.left(180)
    turtle.down()
    draw_flower_and_advance()
    draw_flower_and_advance()
    draw_flower_and_advance()


if __name__ == "__main__" :
    draw_flower_bed()
    turtle.done()