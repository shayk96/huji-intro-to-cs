def secret_function():
    print('My username is shayk96 and I should make sure to check the submission response.')